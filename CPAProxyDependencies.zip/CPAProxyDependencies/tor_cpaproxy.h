/**
	Header file used by CPAProxy to start Tor.
 */
FOUNDATION_EXPORT int tor_main(int argc, const char *argv[]);

FOUNDATION_EXPORT const char tor_git_revision[];
