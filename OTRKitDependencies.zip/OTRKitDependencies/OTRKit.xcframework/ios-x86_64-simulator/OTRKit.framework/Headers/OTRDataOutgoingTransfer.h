//
//  OTRDataOutgoingTransfer.h
//  Pods
//
//  Created by Christopher Ballinger on 12/23/14.
//
//

#import "OTRDataTransfer.h"

@interface OTRDataOutgoingTransfer : OTRDataTransfer

@end
