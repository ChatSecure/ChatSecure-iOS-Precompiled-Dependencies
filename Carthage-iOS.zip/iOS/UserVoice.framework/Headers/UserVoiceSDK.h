//
//  UserVoiceSDK.h
//  UserVoiceSDK
//
//  Created by Paweł Sękara on 19.02.2016.
//  Copyright © 2016 UserVoice Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UserVoiceSDK.
FOUNDATION_EXPORT double UserVoiceSDKVersionNumber;

//! Project version string for UserVoiceSDK.
FOUNDATION_EXPORT const unsigned char UserVoiceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UserVoiceSDK/PublicHeader.h>

#import "UserVoice.h"
